clc;
clear all;
close all;
%%
% ��ȡ����
load ('../mnist to matlab/train_images.mat');
load ('../mnist to matlab/train_labels.mat');
load ('../mnist to matlab/test_images.mat');
load ('../mnist to matlab/test_labels.mat');
%%
Label_Num = 10;
Sigma_M = cell(Label_Num,1);
Mu = cell(Label_Num,1);
%% Train Stage
for i = 1:Label_Num
    ind = train_labels1==i-1;
    Img = train_images(:,:,ind);
    [r,c,n] = size(Img);
    %% HOG
    data = [];
    for j = 1:n
        img = Img(:,:,j)/255;
        [featureVector,hogVisualization] = extractHOGFeatures(img,'CellSize',[8,8]);
        data=[data,featureVector'];
    end
    %%
    mu = mean(data,2);
    tmp = bsxfun(@minus,data,mu);
    CovX = tmp*tmp'/n;
    %%
    Sigma_M{i} = CovX;
    Mu{i} = mu;
end
%% Test Stage
Test_Num = length(test_labels1);
Predicts = zeros(Test_Num,Label_Num);
[r,c,n] = size(test_images);
Test_data=[];
for j = 1:n
    img = test_images(:,:,j)/255;
    [featureVector,hogVisualization] = extractHOGFeatures(img,'CellSize',[8,8]);
    Test_data=[Test_data,featureVector'];
end

for i = 1:Label_Num
    sigma = Sigma_M{i};
    mu = Mu{i};
    Predicts(:,i) = Predict(Test_data,sigma,mu);
end

[v,ind] = max(Predicts,[],2);
predict = ind-1;
accu = sum(predict==test_labels1')/Test_Num;
fprintf('Based the HOG Features, the accuracy is %f.\n',accu);

