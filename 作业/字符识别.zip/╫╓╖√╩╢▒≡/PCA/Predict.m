function P = Predict(Data,sigma,mu,P)
N = size(Data,2);
det_sigma = sqrt(det(sigma));
inv_sigma = inv(sigma);
Item = 1/(2*pi*det_sigma);
Data = P*Data;
Tmp = Data-repmat(mu,[1,N]);
P=[];
for i = 1:N
    xx = Tmp(:,i);
    p=Item*exp(-0.5*xx'*inv_sigma*xx);
    P = [P;p];
end
end

