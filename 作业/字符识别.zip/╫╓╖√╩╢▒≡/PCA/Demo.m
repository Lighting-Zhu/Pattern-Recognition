clc;
clear all;
close all;
%%
Keep_dims = 190;
% ��ȡ����
load ('../mnist to matlab/train_images.mat');
load ('../mnist to matlab/train_labels.mat');
load ('../mnist to matlab/test_images.mat');
load ('../mnist to matlab/test_labels.mat');
%%
Label_Num = 10;
Sigma_M = cell(Label_Num,1);
Mu = cell(Label_Num,1);
Mu_ori = cell(Label_Num,1);
P_M = cell(Label_Num,1);
%% Train Stage
for i = 1:Label_Num
    ind = train_labels1==i-1;
    Img = train_images(:,:,ind);
    [r,c,n] = size(Img);
    tmp = reshape(Img,r*c,n);
    [P,mu_ori] = Get_PCA(tmp,Keep_dims);
    %%
    Mu_ori{i} = mu_ori;
    tmp = bsxfun(@minus,tmp,mu_ori);
    data = P*tmp;
    mu = mean(data,2);
    tmp = bsxfun(@minus,data,mu);
    CovX = tmp*tmp'/n;
    %%
    Sigma_M{i} = CovX;
    Mu{i} = mu;
    P_M{i} = P;
end
%% Test Stage
Test_Num = length(test_labels1);
Predicts = zeros(Test_Num,Label_Num);
[r,c,n] = size(test_images);
Test_data = reshape(test_images,r*c,n);

for i = 1:Label_Num
    sigma = Sigma_M{i};
    mu = Mu{i};
    P = P_M{i};
    mu_ori = Mu_ori{i};
    Test_data1 = bsxfun(@minus,Test_data,mu_ori);
    Predicts(:,i) = Predict(Test_data1,sigma,mu,P);
end

[v,ind] = max(Predicts,[],2);
predict = ind-1;
accu = sum(predict==test_labels1')/Test_Num;
fprintf('Based the remained %d dimensions, the accuracy is %f.\n',Keep_dims,accu);

