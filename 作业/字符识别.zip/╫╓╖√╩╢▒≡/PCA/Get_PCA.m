function [P,mu] = Get_PCA(Data,dims)
n = size(Data,2);
mu = mean(Data,2);
Data = bsxfun(@minus,Data,mu);
CovX = Data*Data'/n;
[P,V]=eig(CovX);
V=diag(V);
[t,ind]=sort(-V);
V=V(ind);
P=P(:,ind);
P=P';
P = P(1:dims,:);
end

