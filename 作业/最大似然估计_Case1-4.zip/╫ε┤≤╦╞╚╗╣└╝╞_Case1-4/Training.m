function [mu1_hat,mu2_hat,sigma1_hat,sigma2_hat] = Training(data1,data2,Case)
% ��������
%%
Training_Num1 = size(data1,1);
Training_Num2 = size(data2,1);
%% ѵ��
mu1_hat = mean(data1,1);
mu2_hat = mean(data2,1);

Tmp1 = data1-repmat(mu1_hat,[Training_Num1,1]);
Tmp2 = data2-repmat(mu2_hat,[Training_Num2,1]);
sigma1_hat = Tmp1'*Tmp1/Training_Num1;
sigma2_hat =Tmp2'*Tmp2/Training_Num2;
%%
if Case ==1 || Case==2
    tmp = mean([diag(sigma1_hat); diag(sigma2_hat)]);
    sigma1_hat = diag([tmp,tmp]);
    sigma2_hat = diag([tmp,tmp]);
elseif Case==3 || Case==4
    sigma1_hat = (sigma1_hat + sigma2_hat)*0.5;
    sigma2_hat = sigma1_hat;
end
end

