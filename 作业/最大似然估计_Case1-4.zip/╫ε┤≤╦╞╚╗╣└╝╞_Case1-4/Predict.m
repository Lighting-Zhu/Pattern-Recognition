function P = Predict(Data,sigma,mu,PP)
N = size(Data,1);
det_sigma = sqrt(det(sigma));
inv_sigma = inv(sigma);
Item = 1/(2*pi*det_sigma);
Tmp = Data-repmat(mu,[N,1]);
P=[];
for i = 1:N
    xx = Tmp(i,:)';
    p=Item*exp(-0.5*xx'*inv_sigma*xx)*PP;
    P = [P;p];
end
end

