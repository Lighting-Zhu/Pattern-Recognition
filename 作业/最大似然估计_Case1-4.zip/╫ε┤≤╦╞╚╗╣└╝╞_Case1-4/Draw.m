function Draw(data1,data2,mu1_hat,mu2_hat,sigma1_hat,sigma2_hat,Case,P)
if Case<5
    figure(1),plot(data1(:,1),data1(:,2),'r+');hold on;
    plot(data2(:,1),data2(:,2),'b*');hold on;
    scatter(mu1_hat(1),mu1_hat(2),120,'b.');
    scatter(mu2_hat(1),mu2_hat(2),120,'r.');
    scatter((mu1_hat(1)+mu2_hat(1))/2,(mu1_hat(2)+mu2_hat(2))/2,120,'k.');
    
    line([mu1_hat(1) mu2_hat(1)],[mu1_hat(2) mu2_hat(2)]);
    P1 = P(Case,1);
    P2 = P(Case,2);
    mu = (mu1_hat - mu2_hat)';
    w=inv(sigma1_hat)*mu;
    tmp = log(P1/P2)/(mu'*inv(sigma1_hat)*mu);
    x0 = (mu1_hat' + mu2_hat')/2-tmp*mu;
    data = [data1;data2];
    minx = min(data(:,1));
    maxx = max(data(:,1));
    x = minx:0.1:maxx;
    y = x0(2)-(w(1)*(x-x0(1))/w(2));
    plot(x,y,'k--');
    axis equal;
    name = sprintf('The classified edge under Case %d',Case);
    title(name);
end
end

