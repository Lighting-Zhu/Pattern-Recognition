function [data1, data2] = GenerateData(Case)
NUM = 500;
if Case==1||Case==2
    mu1 = [2 3];
    sigma1 = [0.5 0;
        0 0.5];
    mu2 = [5 5];
    sigma2 = [0.5 0;
        0 0.5];
elseif Case==3 || Case==4
    mu1 = [2 3];
    sigma1 = [0.5 0.2;
        0.2 0.6];
    mu2 = [5 5];
    sigma2 = [0.5 0.2;
        0.2 0.6];
else
    mu1 = [2 3];
    sigma1 = [0.5 0.2;
        0.2 0.6];
    mu2 = [5 5];
    sigma2 = [0.7 0;
        0 0.8];
end
randn('seed',2020);
data1 = mvnrnd(mu1,sigma1,NUM);
randn('seed',2021);
data2 = mvnrnd(mu2,sigma2,NUM);
end

